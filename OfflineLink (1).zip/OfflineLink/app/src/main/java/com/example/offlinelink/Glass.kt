package com.example.offlinelink

import android.os.Build
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlin.math.roundToInt

object Pal {
    val bg = Color(0xFF07080F)
    val violet = Color(0xFF7C5CFF)
    val blue = Color(0xFF3AA0FF)
    val pink = Color(0xFFFF5CAA)
    val text = Color(0xFFF4F5FA)
    val sub = Color(0xFFF4F5FA).copy(alpha = 0.66f)
    val ok = Color(0xFF3DDB85)
    val warn = Color(0xFFFFB84D)
}

// ---------------------------------------------------------------------------
// Backdrop blur. Compose can't sample what is already on screen behind a view,
// so the scene (background + content) is recorded into a layer; glass panels
// draw that layer again, blurred and clipped to their own outline.
// ---------------------------------------------------------------------------

class Scene(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

val LocalScene = staticCompositionLocalOf<Scene?> { null }

fun Modifier.recordScene(scene: Scene): Modifier = this
    .onGloballyPositioned { scene.origin = it.positionInWindow() }
    .drawWithContent {
        if (Build.VERSION.SDK_INT >= 31) {
            scene.layer.record(size = IntSize(size.width.roundToInt(), size.height.roundToInt())) {
                this@drawWithContent.drawContent()
            }
            drawLayer(scene.layer)
        } else {
            drawContent()
        }
    }

internal val RimBrush = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = 0.42f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.16f))
)

/** Translucent tinted fill with a lit rim. No blur, so it is cheap. */
fun Modifier.frost(shape: Shape, tint: Color = Color.White.copy(alpha = 0.07f)): Modifier = this
    .background(
        Brush.verticalGradient(listOf(tint.copy(alpha = (tint.alpha + 0.05f).coerceAtMost(1f)), tint)),
        shape
    )
    .border(1.dp, RimBrush, shape)

/** Real frosted glass: blurs whatever the scene has behind this element. Needs Android 12+. */
@Composable
fun Modifier.glass(
    shape: Shape,
    tint: Color = Color.White.copy(alpha = 0.08f),
    blur: Dp = 26.dp
): Modifier {
    val scene = LocalScene.current
    val blurLayer = rememberGraphicsLayer()
    var here by remember { mutableStateOf(Offset.Zero) }
    val canBlur = scene != null && Build.VERSION.SDK_INT >= 31
    val fill = if (canBlur) tint else Color(0xFF14152B).copy(alpha = 0.88f)
    return this
        .onGloballyPositioned { here = it.positionInWindow() }
        .drawBehind {
            if (scene != null && Build.VERSION.SDK_INT >= 31) {
                val r = blur.toPx()
                val pad = r * 2f
                val w = (size.width + pad * 2f).roundToInt()
                val h = (size.height + pad * 2f).roundToInt()
                if (w > 0 && h > 0) {
                    blurLayer.renderEffect = BlurEffect(r, r, TileMode.Clamp)
                    blurLayer.record(size = IntSize(w, h)) {
                        translate(scene.origin.x - here.x + pad, scene.origin.y - here.y + pad) {
                            drawLayer(scene.layer)
                        }
                    }
                    val outline = shape.createOutline(size, layoutDirection, this)
                    val path = Path().apply { addOutline(outline) }
                    clipPath(path) {
                        translate(-pad, -pad) { drawLayer(blurLayer) }
                    }
                }
            }
        }
        .frost(shape, fill)
}

// ---------------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------------

@Composable
fun Txt(
    text: String,
    size: Int,
    weight: FontWeight = FontWeight.Bold,
    color: Color = Pal.text,
    modifier: Modifier = Modifier,
    spacing: Float = 0f,
    maxLines: Int = Int.MAX_VALUE
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size.sp,
            fontWeight = weight,
            letterSpacing = spacing.sp,
            lineHeight = (size * 1.25f).sp
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun Pressable(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(dampingRatio = 0.5f, stiffness = 650f),
        label = "press"
    )
    Box(
        modifier
            .graphicsLayer { scaleX = s; scaleY = s }
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        content = content
    )
}

@Composable
fun Aurora(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    val b by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse),
        label = "b"
    )
    Canvas(modifier) {
        drawRect(Pal.bg)
        val w = size.width
        val h = size.height
        blob(Pal.violet, Offset(w * (0.15f + 0.55f * a), h * (0.12f + 0.12f * b)), w * 0.9f, 0.50f)
        blob(Pal.blue, Offset(w * (0.95f - 0.5f * b), h * (0.46f + 0.10f * a)), w * 0.8f, 0.36f)
        blob(Pal.pink, Offset(w * (0.2f + 0.3f * a), h * (0.92f - 0.15f * b)), w * 0.75f, 0.30f)
    }
}

private fun DrawScope.blob(c: Color, center: Offset, r: Float, alpha: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(c.copy(alpha = alpha), Color.Transparent), center = center, radius = r),
        radius = r,
        center = center
    )
}

// ---------------------------------------------------------------------------
// Icons (drawn, no icon library needed)
// ---------------------------------------------------------------------------

@Composable
fun SendIcon(modifier: Modifier = Modifier) = Canvas(modifier) {
    val w = size.width
    val sw = w * 0.11f
    drawLine(Color.White, Offset(w * 0.5f, w * 0.82f), Offset(w * 0.5f, w * 0.2f), sw, StrokeCap.Round)
    drawLine(Color.White, Offset(w * 0.5f, w * 0.2f), Offset(w * 0.24f, w * 0.46f), sw, StrokeCap.Round)
    drawLine(Color.White, Offset(w * 0.5f, w * 0.2f), Offset(w * 0.76f, w * 0.46f), sw, StrokeCap.Round)
}

@Composable
fun BackIcon(modifier: Modifier = Modifier) = Canvas(modifier) {
    val w = size.width
    val sw = w * 0.1f
    drawLine(Color.White, Offset(w * 0.62f, w * 0.2f), Offset(w * 0.34f, w * 0.5f), sw, StrokeCap.Round)
    drawLine(Color.White, Offset(w * 0.34f, w * 0.5f), Offset(w * 0.62f, w * 0.8f), sw, StrokeCap.Round)
}

@Composable
fun BroadcastIcon(modifier: Modifier = Modifier) = Canvas(modifier) {
    val c = center
    val w = size.width
    val sw = w * 0.085f
    drawCircle(Color.White, radius = w * 0.09f, center = c)
    for (k in 1..2) {
        val r = w * (0.2f + 0.16f * k)
        val tl = Offset(c.x - r, c.y - r)
        val sz = Size(r * 2f, r * 2f)
        drawArc(
            color = Color.White, startAngle = -50f, sweepAngle = 100f, useCenter = false,
            topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round)
        )
        drawArc(
            color = Color.White, startAngle = 130f, sweepAngle = 100f, useCenter = false,
            topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun SearchIcon(modifier: Modifier = Modifier) = Canvas(modifier) {
    val w = size.width
    val sw = w * 0.1f
    drawCircle(Color.White, radius = w * 0.26f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(sw))
    drawLine(Color.White, Offset(w * 0.62f, w * 0.62f), Offset(w * 0.82f, w * 0.82f), sw, StrokeCap.Round)
}

// Material-style 24x24 icon paths
const val ICON_CALL = "M6.62,10.79c1.44,2.83 3.76,5.14 6.59,6.59l2.2,-2.2c0.27,-0.27 0.67,-0.36 1.02,-0.24 1.12,0.37 2.33,0.57 3.57,0.57 0.55,0 1,0.45 1,1V20c0,0.55 -0.45,1 -1,1 -9.39,0 -17,-7.61 -17,-17 0,-0.55 0.45,-1 1,-1h3.5c0.55,0 1,0.45 1,1 0,1.25 0.2,2.45 0.57,3.57 0.11,0.35 0.03,0.74 -0.25,1.02l-2.2,2.2z"
const val ICON_VIDEO = "M17,10.5V7c0,-0.55 -0.45,-1 -1,-1H4c-0.55,0 -1,0.45 -1,1v10c0,0.55 0.45,1 1,1h12c0.55,0 1,-0.45 1,-1v-3.5l4,4v-11l-4,4z"
const val ICON_MIC = "M12,14c1.66,0 2.99,-1.34 2.99,-3L15,5c0,-1.66 -1.34,-3 -3,-3S9,3.34 9,5v6c0,1.66 1.34,3 3,3zM17.3,11c0,3 -2.54,5.1 -5.3,5.1S6.7,14 6.7,11H5c0,3.41 2.72,6.23 6,6.72V21h2v-3.28c3.28,-0.48 6,-3.3 6,-6.72h-1.7z"
const val ICON_SPEAKER = "M3,9v6h4l5,5V4L7,9H3zM16.5,12c0,-1.77 -1.02,-3.29 -2.5,-4.03v8.05c1.48,-0.73 2.5,-2.25 2.5,-4.02zM14,3.23v2.06c2.89,0.86 5,3.54 5,6.71s-2.11,5.85 -5,6.71v2.06c4.01,-0.91 7,-4.49 7,-8.77s-2.99,-7.86 -7,-8.77z"
const val ICON_PLAY = "M8,5v14l11,-7z"
const val ICON_PAUSE = "M6,19h4V5H6v14zM14,5v14h4V5h-4z"
const val ICON_PLUS = "M19,13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"
const val ICON_FILE = "M14,2H6c-1.1,0 -2,0.9 -2,2v16c0,1.1 0.89,2 1.99,2H18c1.1,0 2,-0.9 2,-2V8l-6,-6zM13,9V3.5L18.5,9H13z"
const val ICON_TRASH = "M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6v12zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z"

@Composable
fun SvgIcon(
    d: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    rot: Float = 0f,
    slash: Boolean = false
) {
    val path = remember(d) { PathParser().parsePathString(d).toPath() }
    Canvas(modifier) {
        val s = size.minDimension / 24f
        withTransform({
            scale(s, s, Offset.Zero)
            rotate(rot, Offset(12f, 12f))
        }) { drawPath(path, color) }
        if (slash) {
            val w = size.minDimension
            drawLine(color, Offset(w * 0.18f, w * 0.12f), Offset(w * 0.84f, w * 0.9f), w * 0.09f, StrokeCap.Round)
        }
    }
}
