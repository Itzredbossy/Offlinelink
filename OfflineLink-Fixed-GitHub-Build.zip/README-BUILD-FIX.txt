OFFLINELINK BUILD FIX

This bundle fixes the Kotlin compile error reported by GitHub Actions:
MainActivity.kt:178:50 Unresolved reference: LayoutParams

The ScrollView child now uses ViewGroup.LayoutParams, which is valid for the
ScrollView.addView overload used here.

The workflow is at .github/workflows/build-apk.yml at the repository root.
It locates the Android project at the repository root, project/OfflineLink,
OfflineLink, project, or by searching for settings.gradle.kts.
It builds app:assembleDebug with Java 17 and Gradle 8.9 and uploads
app-debug.apk as the OfflineLink-debug-apk artifact.

After extracting this ZIP into your GitHub repository, commit and push.
Then open Actions, select Build OfflineLink APK, and download the artifact
from a successful run.

Note: The source fix addresses the exact compiler error in the supplied log.
A successful Android build still needs to be confirmed by running the workflow.
