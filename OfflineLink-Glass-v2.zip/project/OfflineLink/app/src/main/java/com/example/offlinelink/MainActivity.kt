package com.example.offlinelink

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.NetworkInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pDeviceList
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import android.util.Base64

/**
 * OfflineLink – professional liquid-glass messaging over Wi-Fi Direct.
 * Pure peer-to-peer, no internet, no router.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel

    // Root & screens
    private lateinit var root: FrameLayout
    private lateinit var connectScreen: LinearLayout
    private lateinit var chatScreen: LinearLayout
    private lateinit var infoScreen: LinearLayout
    private lateinit var bottomNav: LinearLayout

    // Connect screen views
    private lateinit var statusTitle: TextView
    private lateinit var statusDetail: TextView
    private lateinit var statusDot: View
    private lateinit var peerPanel: LinearLayout
    private lateinit var hostButton: LinearLayout
    private lateinit var joinButton: LinearLayout

    // Chat screen views
    private lateinit var chatHeaderTitle: TextView
    private lateinit var chatHeaderSubtitle: TextView
    private lateinit var messagesPanel: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendButton: LinearLayout

    // Nav items
    private lateinit var navLink: LinearLayout
    private lateinit var navChat: LinearLayout
    private lateinit var navInfo: LinearLayout

    private val io = Executors.newCachedThreadPool()
    private val socketClosed = AtomicBoolean(false)
    @Volatile private var socket: Socket? = null
    @Volatile private var writer: BufferedWriter? = null
    @Volatile private var server: ServerSocket? = null
    @Volatile private var serverStarted = false
    @Volatile private var socketConnecting = false
    @Volatile private var isHost = false
    @Volatile private var connected = false
    private var receiverRegistered = false
    private var peers: List<WifiP2pDevice> = emptyList()
    private var pendingPermissionAction: (() -> Unit)? = null
    private var currentScreen = 0 // 0=Link, 1=Chat, 2=Info

    private var toneGen: ToneGenerator? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) pendingPermissionAction?.invoke()
        else toast("Nearby Wi-Fi permission is required")
        pendingPermissionAction = null
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        setStatus("Ready to link", "Wi-Fi Direct is on · create or join a private link")
                    } else {
                        setStatus("Turn on Wi-Fi", "Wi-Fi must be enabled on both phones")
                    }
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> requestPeers()
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    val network = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                    if (network?.isConnected == true) requestConnectionInfo()
                    else if (connected) onSocketLost("Wi-Fi Direct connection lost")
                }
                WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> Unit
            }
        }
    }

    private val connectionInfoListener = WifiP2pManager.ConnectionInfoListener { info ->
        if (!info.groupFormed || info.groupOwnerAddress == null) return@ConnectionInfoListener
        val address = info.groupOwnerAddress.hostAddress ?: return@ConnectionInfoListener
        if (info.isGroupOwner) startServer() else connectToHost(address)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Immersive light status bar
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        try {
            toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
        } catch (_: Exception) {}

        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper) {
            runOnUiThread { setStatus("Wi-Fi Direct unavailable", "Restart Wi-Fi and try again") }
        }

        buildInterface()
        registerP2pReceiver()
        setStatus("Ready to link", "Direct phone-to-phone · No internet required")
        showScreen(0)
    }

    // ───────────────────────── UI BUILD ─────────────────────────

    private fun buildInterface() {
        root = FrameLayout(this)
        setContentView(root)

        // Soft gradient background
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#F5F7FF"), Color.parseColor("#E8EEFF"), Color.parseColor("#F0F4FF"))
        )
        root.background = bg

        // Screens container
        val content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        connectScreen = buildConnectScreen()
        chatScreen = buildChatScreen()
        infoScreen = buildInfoScreen()

        content.addView(connectScreen, FrameLayout.LayoutParams(-1, -1))
        content.addView(chatScreen, FrameLayout.LayoutParams(-1, -1))
        content.addView(infoScreen, FrameLayout.LayoutParams(-1, -1))

        // Bottom glass navigation
        bottomNav = buildBottomNav()
        val navParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        navParams.setMargins(dp(16), 0, dp(16), dp(20))
        root.addView(bottomNav, navParams)
    }

    private fun buildConnectScreen(): LinearLayout {
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(100))
        }

        // Brand header
        val brandRow = row().apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_link)
            setColorFilter(Color.parseColor("#5B6CFF"))
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(10) }
        }
        brandRow.addView(logo)
        brandRow.addView(text("Offline", 28, Color.parseColor("#1A1C2E"), true))
        brandRow.addView(text("Link", 28, Color.parseColor("#5B6CFF"), true))
        screen.addView(brandRow, lp(-1, -2))
        screen.addView(text("Private messages. Direct connection.", 14, Color.parseColor("#5A6278"), false).apply {
            setPadding(0, dp(4), 0, dp(22))
        }, lp(-1, -2))

        // Status glass card
        val statusCard = glassCard(20)
        val statusInner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusDot = View(this).apply {
            background = circle(Color.parseColor("#F39C12"))
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(12) }
        }
        statusInner.addView(statusDot)
        val statusTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusTitle = text("Ready to link", 17, Color.parseColor("#1A1C2E"), true)
        statusDetail = text("Direct phone-to-phone · No internet", 13, Color.parseColor("#5A6278"), false)
        statusTexts.addView(statusTitle)
        statusTexts.addView(statusDetail.apply { setPadding(0, dp(2), 0, 0) })
        statusInner.addView(statusTexts, LinearLayout.LayoutParams(0, -2, 1f))
        statusCard.addView(statusInner)
        screen.addView(statusCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        // Action buttons row
        val actions = row().apply { setPadding(0, 0, 0, dp(18)) }
        hostButton = iconButton("Host", R.drawable.ic_host, Color.parseColor("#5B6CFF")) {
            playClick(); withPermissions { host() }
        }
        joinButton = iconButton("Find", R.drawable.ic_search, Color.parseColor("#00B8D9")) {
            playClick(); withPermissions { discover() }
        }
        actions.addView(hostButton, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginEnd = dp(8) })
        actions.addView(joinButton, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginStart = dp(8) })
        screen.addView(actions, lp(-1, -2))

        // Nearby section
        val nearbyHeader = row().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), dp(10))
        }
        nearbyHeader.addView(text("NEARBY PHONES", 12, Color.parseColor("#8B93A8"), true), LinearLayout.LayoutParams(0, -2, 1f))
        screen.addView(nearbyHeader, lp(-1, -2))

        val peersCard = glassCard(18)
        peerPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        peersCard.addView(peerPanel)
        screen.addView(peersCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        // Empty state initially
        showEmptyPeers()

        return screen
    }

    private fun buildChatScreen(): LinearLayout {
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(48), dp(16), dp(100))
            visibility = View.GONE
        }

        // Chat header glass
        val header = glassCard(18)
        val headerRow = row().apply { gravity = Gravity.CENTER_VERTICAL }
        val avatar = View(this).apply {
            background = circle(Color.parseColor("#5B6CFF"))
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(12) }
        }
        headerRow.addView(avatar)
        val headerTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatHeaderTitle = text("Direct Link", 17, Color.parseColor("#1A1C2E"), true)
        chatHeaderSubtitle = text("Not connected", 13, Color.parseColor("#5A6278"), false)
        headerTexts.addView(chatHeaderTitle)
        headerTexts.addView(chatHeaderSubtitle)
        headerRow.addView(headerTexts, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(headerRow)
        screen.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        // Messages area
        scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        messagesPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(12))
        }
        scroll.addView(messagesPanel, ViewGroup.LayoutParams(-1, -2))
        screen.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Composer glass
        val composer = glassCard(28).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        input = EditText(this).apply {
            hint = "Message…"
            setHintTextColor(Color.parseColor("#8B93A8"))
            setTextColor(Color.parseColor("#1A1C2E"))
            textSize = 15f
            maxLines = 4
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(14), dp(10), dp(8), dp(10))
            isEnabled = false
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        sendButton = iconOnlyButton(R.drawable.ic_send, Color.parseColor("#5B6CFF")) {
            playClick(); sendMessage()
        }.apply {
            isEnabled = false
            alpha = 0.45f
        }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        composer.addView(sendButton, lp(dp(48), dp(48)))
        screen.addView(composer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        addSystemMessage("Choose Host on one phone and Find on the other to start chatting.")
        return screen
    }

    private fun buildInfoScreen(): LinearLayout {
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(100))
            visibility = View.GONE
        }

        screen.addView(text("About OfflineLink", 24, Color.parseColor("#1A1C2E"), true).apply {
            setPadding(0, 0, 0, dp(16))
        }, lp(-1, -2))

        val card1 = glassCard(18)
        card1.addView(text("How it works", 16, Color.parseColor("#1A1C2E"), true))
        card1.addView(text(
            "OfflineLink creates a pure peer-to-peer Wi-Fi Direct connection between two phones. No router, no mobile data, no internet. Messages travel over a local TCP socket on the private link.",
            14, Color.parseColor("#5A6278"), false
        ).apply { setPadding(0, dp(8), 0, 0) })
        screen.addView(card1, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val card2 = glassCard(18)
        card2.addView(text("Tips", 16, Color.parseColor("#1A1C2E"), true))
        card2.addView(text(
            "• Keep both phones unlocked and close while connecting\n• On Android 12 and below, Location must be ON\n• Range depends on environment (walls reduce it)\n• This build does not encrypt messages yet",
            14, Color.parseColor("#5A6278"), false
        ).apply { setPadding(0, dp(8), 0, 0) })
        screen.addView(card2, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val card3 = glassCard(18)
        card3.addView(text("Privacy", 16, Color.parseColor("#1A1C2E"), true))
        card3.addView(text(
            "All traffic stays on the local Wi-Fi Direct group. Nothing is sent to any server.",
            14, Color.parseColor("#5A6278"), false
        ).apply { setPadding(0, dp(8), 0, 0) })
        // Cyan link style text
        val link = text("Learn more about Wi-Fi Direct", 14, Color.parseColor("#00B8D9"), true).apply {
            setPadding(0, dp(10), 0, 0)
            setOnClickListener { playClick(); toast("Opens system Wi-Fi Direct info (future)") }
        }
        card3.addView(link)
        screen.addView(card3, lp(-1, -2))

        return screen
    }

    private fun buildBottomNav(): LinearLayout {
        val nav = glassCard(28).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            elevation = dp(12).toFloat()
        }

        navLink = navItem("Link", R.drawable.ic_link, true) { showScreen(0) }
        navChat = navItem("Chat", R.drawable.ic_chat, false) { showScreen(1) }
        navInfo = navItem("Info", R.drawable.ic_info, false) { showScreen(2) }

        nav.addView(navLink, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navChat, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navInfo, LinearLayout.LayoutParams(0, -2, 1f))
        return nav
    }

    private fun navItem(label: String, iconRes: Int, active: Boolean, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
            isClickable = true
            isFocusable = true
            setOnClickListener { playClick(); action() }

            val icon = ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (active) Color.parseColor("#5B6CFF") else Color.parseColor("#A0A8C0"))
                layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
            }
            val txt = text(label, 11, if (active) Color.parseColor("#5B6CFF") else Color.parseColor("#A0A8C0"), true)
            addView(icon)
            addView(txt.apply { setPadding(0, dp(3), 0, 0) })
            tag = icon to txt
        }
    }

    private fun updateNav(selected: Int) {
        listOf(navLink, navChat, navInfo).forEachIndexed { i, item ->
            val (icon, txt) = item.tag as Pair<ImageView, TextView>
            val active = i == selected
            icon.setColorFilter(if (active) Color.parseColor("#5B6CFF") else Color.parseColor("#A0A8C0"))
            txt.setTextColor(if (active) Color.parseColor("#5B6CFF") else Color.parseColor("#A0A8C0"))
        }
    }

    private fun showScreen(index: Int) {
        currentScreen = index
        connectScreen.visibility = if (index == 0) View.VISIBLE else View.GONE
        chatScreen.visibility = if (index == 1) View.VISIBLE else View.GONE
        infoScreen.visibility = if (index == 2) View.VISIBLE else View.GONE
        updateNav(index)

        // Subtle entrance
        val target = when (index) {
            0 -> connectScreen
            1 -> chatScreen
            else -> infoScreen
        }
        target.alpha = 0f
        target.translationY = dp(12).toFloat()
        target.animate().alpha(1f).translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator()).start()
    }

    // ───────────────────────── HELPERS ─────────────────────────

    private fun glassCard(radius: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.parseColor("#E6FFFFFF"), Color.parseColor("#99FFFFFF"), radius)
        elevation = dp(4).toFloat()
    }

    private fun iconButton(label: String, iconRes: Int, color: Int, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(color, Color.parseColor("#40FFFFFF"), 18)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            elevation = dp(3).toFloat()

            val icon = ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(8) }
            }
            addView(icon)
            addView(text(label, 15, Color.WHITE, true))
        }
    }

    private fun iconOnlyButton(iconRes: Int, color: Int, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = circle(color)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            val icon = ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
            }
            addView(icon)
        }
    }

    private fun showEmptyPeers() {
        peerPanel.removeAllViews()
        val empty = text("No phones found yet.\nKeep both devices nearby and tap Find.", 14, Color.parseColor("#8B93A8"), false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(20), dp(12), dp(20))
        }
        peerPanel.addView(empty)
    }

    private fun playClick() {
        try { toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 40) } catch (_: Exception) {}
        try {
            val v = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(18)
            }
        } catch (_: Exception) {}
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        else typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    // ───────────────────────── P2P LOGIC (kept intact) ─────────────────────────

    @Suppress("DEPRECATION")
    private fun registerP2pReceiver() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, filter)
        receiverRegistered = true
    }

    private fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun withPermissions(action: () -> Unit) {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) action() else {
            pendingPermissionAction = action
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun host() {
        closeTransport()
        isHost = true
        setStatus("Starting group…", "This phone will host the private Wi-Fi link")
        peerPanel.removeAllViews()
        showEmptyPeers()
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = createHostGroup()
            override fun onFailure(reason: Int) = createHostGroup()
        })
    }

    @Suppress("MissingPermission")
    private fun createHostGroup() {
        manager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                runOnUiThread {
                    setStatus("Hosting", "Waiting for another phone to join")
                    statusDot.background = circle(Color.parseColor("#2ECC71"))
                }
            }
            override fun onFailure(reason: Int) {
                runOnUiThread {
                    setStatus("Couldn't start hosting", p2pError(reason))
                    addSystemMessage("Host failed: ${p2pError(reason)}")
                }
            }
        })
    }

    private fun discover() {
        closeTransport()
        isHost = false
        peers = emptyList()
        peerPanel.removeAllViews()
        showEmptyPeers()
        setStatus("Searching nearby…", "Keep this screen open while scanning")
        statusDot.background = circle(Color.parseColor("#00B8D9"))
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { runOnUiThread { addSystemMessage("Searching for nearby Wi-Fi Direct devices…") } }
            override fun onFailure(reason: Int) {
                runOnUiThread {
                    setStatus("Search couldn't start", p2pError(reason))
                    addSystemMessage(p2pError(reason))
                }
            }
        })
    }

    @Suppress("MissingPermission")
    private fun requestPeers() {
        manager.requestPeers(channel) { list: WifiP2pDeviceList ->
            peers = list.deviceList.filter { it.status != WifiP2pDevice.UNAVAILABLE }
            runOnUiThread { renderPeers() }
        }
    }

    private fun renderPeers() {
        peerPanel.removeAllViews()
        if (peers.isEmpty()) {
            showEmptyPeers()
            return
        }
        peers.forEach { device ->
            val item = glassCard(16).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(12), dp(12))
            }
            val icon = ImageView(this).apply {
                setImageResource(R.drawable.ic_phone)
                setColorFilter(Color.parseColor("#5B6CFF"))
                layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(12) }
            }
            item.addView(icon)

            val label = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            label.addView(text(device.deviceName.ifBlank { "Nearby Android phone" }, 15, Color.parseColor("#1A1C2E"), true))
            label.addView(text(deviceStatus(device.status), 12, Color.parseColor("#5A6278"), false))
            item.addView(label, LinearLayout.LayoutParams(0, -2, 1f))

            val connectBtn = iconButton("Connect", R.drawable.ic_connect, Color.parseColor("#5B6CFF")) {
                playClick(); connect(device)
            }.apply {
                // smaller version
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            item.addView(connectBtn, lp(-2, dp(40)))
            peerPanel.addView(item, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

            // Entrance animation
            item.alpha = 0f
            item.translationX = dp(30).toFloat()
            item.animate().alpha(1f).translationX(0f).setDuration(300)
                .setInterpolator(OvershootInterpolator(0.8f)).start()
        }
    }

    @Suppress("MissingPermission")
    private fun connect(device: WifiP2pDevice) {
        setStatus("Connecting…", "Negotiating link with ${device.deviceName}")
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { runOnUiThread { addSystemMessage("Connection request sent to ${device.deviceName}.") } }
            override fun onFailure(reason: Int) { runOnUiThread { setStatus("Connection failed", p2pError(reason)) } }
        })
    }

    @Suppress("MissingPermission")
    private fun requestConnectionInfo() {
        manager.requestConnectionInfo(channel, connectionInfoListener)
    }

    private fun startServer() {
        if (serverStarted) return
        serverStarted = true
        io.execute {
            try {
                val ss = ServerSocket(PORT)
                server = ss
                val accepted = ss.accept()
                attachSocket(accepted)
            } catch (e: Exception) {
                if (!socketClosed.get()) runOnUiThread { setStatus("Waiting for peer", e.message ?: "Socket server stopped") }
            }
        }
        runOnUiThread { setStatus("Wi-Fi Direct active", "Group created · waiting for chat socket") }
    }

    private fun connectToHost(address: String) {
        if (connected || socket != null || socketConnecting) return
        socketConnecting = true
        io.execute {
            try {
                val s = Socket()
                s.connect(java.net.InetSocketAddress(address, PORT), 12000)
                socketConnecting = false
                attachSocket(s)
            } catch (e: Exception) {
                socketConnecting = false
                runOnUiThread { setStatus("Socket connection failed", e.message ?: "Try reconnecting") }
            }
        }
    }

    private fun attachSocket(s: Socket) {
        socket = s
        socketClosed.set(false)
        writer = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
        connected = true
        socketConnecting = false
        runOnUiThread {
            setStatus("Connected", "Direct local link · messages are live")
            statusDot.background = circle(Color.parseColor("#2ECC71"))
            chatHeaderTitle.text = "Direct Link"
            chatHeaderSubtitle.text = "Connected · Wi-Fi Direct"
            input.isEnabled = true
            sendButton.isEnabled = true
            sendButton.alpha = 1f
            addSystemMessage("Secure transport connected. You can chat now.")
            // Auto switch to chat
            showScreen(1)
        }
        io.execute {
            try {
                val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                while (!s.isClosed) {
                    val line = reader.readLine() ?: break
                    val decoded = try {
                        String(Base64.decode(line, Base64.NO_WRAP), Charsets.UTF_8)
                    } catch (_: Exception) { continue }
                    runOnUiThread { addMessage(decoded, false) }
                }
            } catch (_: Exception) {
            } finally {
                if (!socketClosed.get()) onSocketLost("Peer disconnected")
            }
        }
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        val out = writer
        if (!connected || out == null) {
            toast("Not connected yet")
            return
        }
        val encoded = Base64.encodeToString(message.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        io.execute {
            try {
                synchronized(out) { out.write(encoded); out.newLine(); out.flush() }
                runOnUiThread {
                    addMessage(message, true)
                    input.setText("")
                }
            } catch (e: Exception) {
                runOnUiThread { onSocketLost("Message could not be sent") }
            }
        }
    }

    private fun onSocketLost(reason: String) {
        connected = false
        closeSocketOnly()
        runOnUiThread {
            input.isEnabled = false
            sendButton.isEnabled = false
            sendButton.alpha = 0.45f
            setStatus("Disconnected", reason)
            statusDot.background = circle(Color.parseColor("#E74C3C"))
            chatHeaderSubtitle.text = "Disconnected"
            addSystemMessage(reason)
        }
    }

    private fun closeSocketOnly() {
        socketClosed.set(true)
        try { writer?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        writer = null
        socket = null
    }

    private fun closeTransport() {
        connected = false
        serverStarted = false
        socketConnecting = false
        closeSocketOnly()
        try { server?.close() } catch (_: Exception) {}
        server = null
        input.isEnabled = false
        sendButton.isEnabled = false
        sendButton.alpha = 0.45f
    }

    private fun addMessage(message: String, mine: Boolean) {
        val bubble = TextView(this).apply {
            text = message
            textSize = 15f
            setTextColor(if (mine) Color.WHITE else Color.parseColor("#1A1C2E"))
            setPadding(dp(16), dp(11), dp(16), dp(11))
            background = rounded(
                if (mine) Color.parseColor("#5B6CFF") else Color.parseColor("#FFFFFF"),
                if (mine) Color.parseColor("#40FFFFFF") else Color.parseColor("#33A0A8C0"),
                20
            )
            maxWidth = dp(280)
        }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.END else Gravity.START
            addView(bubble, LinearLayout.LayoutParams(-2, -2))
            alpha = 0f
            translationY = dp(16).toFloat()
            scaleX = 0.92f
            scaleY = 0.92f
        }
        messagesPanel.addView(wrapper, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        wrapper.animate()
            .alpha(1f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(260)
            .setInterpolator(OvershootInterpolator(0.7f))
            .start()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addSystemMessage(message: String) {
        val v = text(message, 12, Color.parseColor("#8B93A8"), false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        messagesPanel.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setStatus(title: String, detail: String) {
        statusTitle.text = title
        statusDetail.text = detail
    }

    private fun p2pError(reason: Int): String = when (reason) {
        WifiP2pManager.P2P_UNSUPPORTED -> "This phone does not support Wi-Fi Direct"
        WifiP2pManager.BUSY -> "Wi-Fi Direct is busy. Wait a moment and retry"
        WifiP2pManager.ERROR -> "Wi-Fi Direct system error"
        else -> "Wi-Fi Direct error ($reason)"
    }

    private fun deviceStatus(status: Int): String = when (status) {
        WifiP2pDevice.AVAILABLE -> "Available"
        WifiP2pDevice.INVITED -> "Invited"
        WifiP2pDevice.CONNECTED -> "Connected"
        WifiP2pDevice.FAILED -> "Connection failed"
        else -> "Nearby device"
    }

    override fun onDestroy() {
        closeTransport()
        try { manager.stopPeerDiscovery(channel, null) } catch (_: Exception) {}
        try { manager.removeGroup(channel, null) } catch (_: Exception) {}
        if (receiverRegistered) try { unregisterReceiver(receiver) } catch (_: Exception) {}
        io.shutdownNow()
        try { toneGen?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val PORT = 8988
    }
}
