package com.example.offlinelink

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.*
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

class Actions(
    val host: () -> Unit,
    val join: () -> Unit,
    val pick: () -> Unit,
    val withMic: (() -> Unit) -> Unit,
    val startCall: (Boolean) -> Unit,
    val answer: () -> Unit
)

private val RED = Color(0xFFFF3B5C)

// ---------------------------------------------------------------------------
// Root
// ---------------------------------------------------------------------------

@Composable
fun OfflineLinkApp(link: LinkController, recorder: VoiceRecorder, actions: Actions) {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf(readiness(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { ready = readiness(ctx); delay(1500) }
    }
    val view = LocalView.current
    SideEffect { view.keepScreenOn = link.phase != Phase.Idle }

    val layer = rememberGraphicsLayer()
    val scene = remember(layer) { Scene(layer) }
    var topPx by remember { mutableIntStateOf(0) }
    var bottomPx by remember { mutableIntStateOf(0) }
    val inChat = link.phase == Phase.Chat

    BackHandler(enabled = link.phase != Phase.Idle) { link.leave() }

    var lastPending by remember { mutableStateOf<Pending?>(null) }
    LaunchedEffect(link.pending) { if (link.pending != null) lastPending = link.pending }
    var shownError by remember { mutableStateOf("") }
    LaunchedEffect(link.error) {
        val e = link.error
        if (e != null) { shownError = e; delay(4500); link.clearError() }
    }

    CompositionLocalProvider(LocalScene provides scene) {
        Box(Modifier.fillMaxSize().background(Pal.bg)) {
            Box(Modifier.fillMaxSize().recordScene(scene)) {
                Aurora(Modifier.fillMaxSize())
                Crossfade(targetState = inChat, animationSpec = tween(350), label = "screen") { chat ->
                    if (chat) Messages(link, topPx, bottomPx) else Home(link, ready, actions)
                }
            }
            AnimatedVisibility(
                visible = inChat, modifier = Modifier.align(Alignment.TopCenter),
                enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut()
            ) { ChatHeader(link, actions, Modifier.onSizeChanged { topPx = it.height }) }

            AnimatedVisibility(
                visible = inChat, modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()
            ) { Composer(link, recorder, actions, Modifier.onSizeChanged { bottomPx = it.height }) }

            AnimatedVisibility(visible = link.pending != null, enter = fadeIn(tween(220)), exit = fadeOut(tween(160))) {
                lastPending?.let { AcceptSheet(it, { link.accept() }, { link.reject() }) }
            }

            AnimatedVisibility(visible = link.callState != CallState.Idle, enter = fadeIn(), exit = fadeOut()) {
                CallScreen(link, actions)
            }

            AnimatedVisibility(
                visible = link.error != null, modifier = Modifier.align(Alignment.TopCenter),
                enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut()
            ) {
                Box(Modifier.statusBarsPadding().padding(16.dp)) {
                    Box(Modifier.glass(RoundedCornerShape(22.dp), tint = Pal.warn.copy(alpha = 0.16f)).padding(16.dp)) {
                        Txt(shownError, 14, FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------

@Composable
fun Home(link: LinkController, ready: Ready, actions: Actions) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 20.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        Row {
            Txt("Offline", 44, FontWeight.Black)
            Txt("Link", 44, FontWeight.Black, Pal.blue)
        }
        Spacer(Modifier.height(4.dp))
        Txt("Chat, call and share with a phone nearby.", 16, FontWeight.Medium, Pal.sub)

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Crossfade(targetState = link.phase, animationSpec = tween(300), label = "home") { ph ->
                if (ph == Phase.Hosting || ph == Phase.Searching) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Radar(hosting = ph == Phase.Hosting)
                        Spacer(Modifier.height(20.dp))
                        Txt(if (ph == Phase.Hosting) "Hosting as ${link.myName}" else "Searching nearby", 21, FontWeight.Black)
                        Spacer(Modifier.height(22.dp))
                        Pressable(onClick = { link.leave() }) {
                            Box(Modifier.frost(CircleShape).padding(horizontal = 26.dp, vertical = 12.dp)) {
                                Txt("Cancel", 15, FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        ActionCard("Host", "Let another phone find you", Pal.violet, actions.host) {
                            BroadcastIcon(Modifier.size(34.dp))
                        }
                        ActionCard("Join", "Find a phone that is hosting", Pal.blue, actions.join) {
                            SearchIcon(Modifier.size(30.dp))
                        }
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(if (ready.wifi) "Wi-Fi" else "Wi-Fi off", ready.wifi)
            Pill(if (ready.bluetooth) "Bluetooth" else "Bluetooth off", ready.bluetooth)
            if (ready.needsLocation) Pill(if (ready.location) "Location" else "Location off", ready.location)
        }
    }
}

@Composable
fun ActionCard(title: String, sub: String, accent: Color, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Pressable(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().frost(RoundedCornerShape(30.dp)).padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(64.dp).clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.55f)))),
                contentAlignment = Alignment.Center
            ) { icon() }
            Spacer(Modifier.width(18.dp))
            Column {
                Txt(title, 24, FontWeight.Black)
                Spacer(Modifier.height(3.dp))
                Txt(sub, 14, FontWeight.Medium, Pal.sub)
            }
        }
    }
}

@Composable
fun Pill(label: String, ok: Boolean) {
    Row(
        Modifier.frost(CircleShape).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (ok) Pal.ok else Pal.warn))
        Spacer(Modifier.width(7.dp))
        Txt(label, 12, FontWeight.Bold, if (ok) Pal.text else Pal.sub)
    }
}

@Composable
fun Radar(hosting: Boolean) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing)), label = "p")
    Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            for (i in 0..2) {
                val f = (p + i / 3f) % 1f
                drawCircle(
                    color = Pal.violet.copy(alpha = (1f - f) * 0.55f),
                    radius = size.minDimension / 2f * f,
                    style = Stroke(2.dp.toPx())
                )
            }
        }
        Box(Modifier.size(92.dp).frost(CircleShape, Color.White.copy(alpha = 0.10f)), contentAlignment = Alignment.Center) {
            if (hosting) BroadcastIcon(Modifier.size(44.dp)) else SearchIcon(Modifier.size(40.dp))
        }
    }
}

// ---------------------------------------------------------------------------
// Chat
// ---------------------------------------------------------------------------

@Composable
fun Messages(link: LinkController, topPx: Int, bottomPx: Int) {
    val d = LocalDensity.current
    val state = rememberLazyListState()
    val n = link.messages.size
    LaunchedEffect(n, bottomPx) { if (n > 0) state.animateScrollToItem(n - 1) }
    val lastMine = link.messages.lastOrNull { it.mine && it.kind != Kind.Call }
    Box(Modifier.fillMaxSize()) {
        if (n == 0) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(link.peerName, 84.dp)
                Spacer(Modifier.height(14.dp))
                Txt(link.peerName, 22, FontWeight.Black)
                Spacer(Modifier.height(4.dp))
                Txt("Say hi", 14, FontWeight.Medium, Pal.sub)
            }
        }
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 14.dp, end = 14.dp,
                top = with(d) { topPx.toDp() } + 12.dp,
                bottom = with(d) { bottomPx.toDp() } + 12.dp
            ),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(link.messages) { m -> Bubble(m, showStatus = !m.sent || m === lastMine) }
        }
    }
}

private fun bubbleShape(mine: Boolean) = RoundedCornerShape(
    topStart = 24.dp, topEnd = 24.dp,
    bottomEnd = if (mine) 8.dp else 24.dp, bottomStart = if (mine) 24.dp else 8.dp
)

@Composable
fun Bubble(m: Msg, showStatus: Boolean) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 380f)) }

    if (m.kind == Kind.Call) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
            Row(Modifier.frost(CircleShape).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                SvgIcon(if (m.text.startsWith("Video")) ICON_VIDEO else ICON_CALL, Modifier.size(16.dp), Pal.sub)
                Spacer(Modifier.width(8.dp))
                Txt(m.text, 13, FontWeight.SemiBold, Pal.sub)
            }
        }
        return
    }

    val shape = bubbleShape(m.mine)
    val isImage = m.kind == Kind.File && isImageName(m.name)
    Column(
        Modifier.fillMaxWidth().graphicsLayer {
            val v = a.value
            alpha = v.coerceIn(0f, 1f)
            translationY = (1f - v) * 48f
            scaleX = 0.92f + 0.08f * v
            scaleY = 0.92f + 0.08f * v
            transformOrigin = TransformOrigin(if (m.mine) 1f else 0f, 1f)
        },
        horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start
    ) {
        val look = if (m.mine && !isImage) {
            Modifier.background(Brush.linearGradient(listOf(Pal.violet.copy(alpha = 0.85f), Pal.blue.copy(alpha = 0.75f))), shape)
                .border(1.dp, RimBrush, shape)
        } else {
            Modifier.frost(shape, Color.White.copy(alpha = 0.09f))
        }
        Box(Modifier.widthIn(max = 290.dp).clip(shape).then(look)) {
            when {
                m.kind == Kind.Text -> Box(Modifier.padding(horizontal = 16.dp, vertical = 11.dp)) { Txt(m.text, 16, FontWeight.SemiBold) }
                m.kind == Kind.Voice -> VoiceBody(m)
                isImage -> ImageBody(m)
                else -> FileBody(m)
            }
        }
        if (showStatus && m.mine) {
            Spacer(Modifier.height(2.dp))
            Txt(if (m.sent) "Sent" else "Waiting for connection", 11, FontWeight.Medium, Pal.sub, Modifier.padding(horizontal = 6.dp))
        }
    }
}

@Composable
fun ProgressBar(p: Float, modifier: Modifier = Modifier) {
    Box(modifier.height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f))) {
        Box(Modifier.fillMaxWidth(p.coerceIn(0f, 1f)).fillMaxHeight().background(Color.White))
    }
}

@Composable
fun VoiceBody(m: Msg) {
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableFloatStateOf(0f) }
    DisposableEffect(Unit) { onDispose { player?.release() } }
    LaunchedEffect(playing) {
        while (playing) {
            val p = player
            if (p != null && m.durMs > 0) pos = (p.currentPosition.toFloat() / m.durMs).coerceIn(0f, 1f)
            delay(80)
        }
    }
    val ready = m.path != null
    fun toggle() {
        val path = m.path ?: return
        val p = player
        if (p == null) {
            try {
                val mp = MediaPlayer().apply {
                    setDataSource(path)
                    prepare()
                    setOnCompletionListener { playing = false; pos = 0f }
                    start()
                }
                player = mp
                playing = true
            } catch (_: Exception) {
            }
        } else if (p.isPlaying) { p.pause(); playing = false } else { p.start(); playing = true }
    }
    Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Pressable(onClick = { toggle() }) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                SvgIcon(if (playing) ICON_PAUSE else ICON_PLAY, Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Waveform(m.name.hashCode() + m.durMs.toInt(), if (ready) pos else m.progress, Modifier.width(120.dp).height(28.dp))
        Spacer(Modifier.width(10.dp))
        val s = (m.durMs / 1000).toInt()
        Txt("${s / 60}:${"%02d".format(s % 60)}", 12, FontWeight.Bold)
    }
}

@Composable
fun Waveform(seed: Int, progress: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = 26
        val step = size.width / n
        for (i in 0 until n) {
            val h = (0.25f + 0.75f * (abs((seed * (i + 7) * 31) % 100) / 100f)) * size.height
            val on = (i + 1f) / n <= progress
            drawLine(
                Color.White.copy(alpha = if (on) 1f else 0.38f),
                Offset(step * i + step / 2, (size.height - h) / 2),
                Offset(step * i + step / 2, (size.height + h) / 2),
                step * 0.5f, StrokeCap.Round
            )
        }
    }
}

private fun isImageName(n: String) = n.substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

private fun decodeImage(path: String): ImageBitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / s > 1000) s *= 2
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
}

private fun openFile(ctx: Context, m: Msg) {
    val path = m.path ?: return
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(m.name.substringAfterLast('.', "").lowercase()) ?: "*/*"
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: ActivityNotFoundException) {
    } catch (_: Exception) {
    }
}

@Composable
fun ImageBody(m: Msg) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, m.path) {
        value = m.path?.let { p -> withContext(Dispatchers.IO) { decodeImage(p) } }
    }
    val b = bmp
    Box(Modifier.width(230.dp).clickable { openFile(ctx, m) }) {
        if (b != null) {
            Image(
                bitmap = b, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio((b.width / b.height.toFloat()).coerceIn(0.6f, 1.6f))
            )
        } else {
            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color.White.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
                if (m.progress < 1f) ProgressBar(m.progress, Modifier.width(120.dp))
            }
        }
    }
}

@Composable
fun FileBody(m: Msg) {
    val ctx = LocalContext.current
    Row(
        Modifier.clickable(enabled = m.path != null) { openFile(ctx, m) }.padding(12.dp).widthIn(min = 200.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            SvgIcon(ICON_FILE, Modifier.size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f, fill = false)) {
            Txt(m.name, 15, FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            val kb = m.size / 1024
            Txt(if (kb >= 1024) "%.1f MB".format(kb / 1024f) else "$kb KB", 12, FontWeight.Medium, Pal.sub)
            if (m.progress < 1f) {
                Spacer(Modifier.height(6.dp))
                ProgressBar(m.progress, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun Avatar(name: String, size: Dp = 44.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(Pal.pink, Pal.violet))),
        contentAlignment = Alignment.Center
    ) {
        Txt(name.take(1).uppercase().ifEmpty { "?" }, (size.value * 0.42f).toInt(), FontWeight.Black, Color.White)
    }
}

@Composable
fun GlassCircle(onClick: () -> Unit, size: Dp = 44.dp, tint: Color = Color.White.copy(alpha = 0.07f), content: @Composable BoxScope.() -> Unit) {
    Pressable(onClick = onClick) {
        Box(Modifier.size(size).frost(CircleShape, tint), contentAlignment = Alignment.Center, content = content)
    }
}

@Composable
fun ChatHeader(link: LinkController, actions: Actions, modifier: Modifier = Modifier) {
    val status: Pair<String, Color> = when {
        !link.online -> "Out of range, reconnecting..." to Pal.warn
        link.linkType == LinkType.Wifi -> "Wi-Fi · long range" to Pal.ok
        link.linkType == LinkType.Bluetooth -> "Bluetooth · short range" to Pal.warn
        else -> "Connected" to Pal.ok
    }
    Column(modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassCircle({ link.leave() }) { BackIcon(Modifier.size(22.dp)) }
            Spacer(Modifier.width(10.dp))
            Avatar(link.peerName, 42.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Txt(link.peerName, 17, FontWeight.Black, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(status.second))
                    Spacer(Modifier.width(5.dp))
                    Txt(status.first, 12, FontWeight.SemiBold, Pal.sub, maxLines = 1)
                }
            }
            GlassCircle({ actions.startCall(false) }, 42.dp) { SvgIcon(ICON_CALL, Modifier.size(20.dp)) }
            Spacer(Modifier.width(6.dp))
            GlassCircle({ actions.startCall(true) }, 42.dp) { SvgIcon(ICON_VIDEO, Modifier.size(22.dp)) }
        }
    }
}

@Composable
fun Composer(link: LinkController, rec: VoiceRecorder, actions: Actions, modifier: Modifier = Modifier) {
    var draft by remember { mutableStateOf("") }
    val can = draft.isNotBlank()
    DisposableEffect(Unit) { onDispose { rec.cancel() } }
    LaunchedEffect(rec.recording) { while (rec.recording) { rec.tick(); delay(200) } }

    Row(
        modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        if (rec.recording) {
            GlassCircle({ rec.cancel() }, 52.dp, Pal.warn.copy(alpha = 0.12f)) { SvgIcon(ICON_TRASH, Modifier.size(22.dp)) }
            Spacer(Modifier.width(10.dp))
            val pulse = rememberInfiniteTransition(label = "rec")
            val al by pulse.animateFloat(0.3f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "al")
            Row(
                Modifier.weight(1f).height(52.dp).glass(CircleShape).padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(RED.copy(alpha = al)))
                Spacer(Modifier.width(12.dp))
                val s = (rec.elapsedMs / 1000).toInt()
                Txt("${s / 60}:${"%02d".format(s % 60)}", 16, FontWeight.Black)
                Spacer(Modifier.width(12.dp))
                Txt("Recording", 14, FontWeight.Medium, Pal.sub)
            }
            Spacer(Modifier.width(10.dp))
            SendButton { rec.stop()?.let { (f, d) -> link.sendVoice(f, d) } }
        } else {
            GlassCircle({ actions.pick() }, 52.dp) { SvgIcon(ICON_PLUS, Modifier.size(24.dp)) }
            Spacer(Modifier.width(10.dp))
            Row(
                Modifier.weight(1f).heightIn(min = 52.dp).glass(RoundedCornerShape(28.dp)).padding(start = 20.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = draft, onValueChange = { draft = it },
                    modifier = Modifier.weight(1f).padding(vertical = 14.dp),
                    textStyle = TextStyle(color = Pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(Pal.blue),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    decorationBox = { inner ->
                        Box { if (draft.isEmpty()) Txt("Message...", 16, FontWeight.Medium, Pal.sub); inner() }
                    }
                )
                if (!can) {
                    Pressable(onClick = { actions.withMic { rec.start() } }) {
                        Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { SvgIcon(ICON_MIC, Modifier.size(24.dp)) }
                    }
                }
            }
            if (can) {
                Spacer(Modifier.width(10.dp))
                SendButton { link.send(draft); draft = "" }
            }
        }
    }
}

@Composable
fun SendButton(onClick: () -> Unit) {
    Pressable(onClick = onClick) {
        Box(
            Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pal.violet, Pal.blue))),
            contentAlignment = Alignment.Center
        ) { SendIcon(Modifier.size(24.dp)) }
    }
}

// ---------------------------------------------------------------------------
// Calls
// ---------------------------------------------------------------------------

@Composable
fun CallScreen(link: LinkController, actions: Actions) {
    val e = link.engine
    val active = link.callState == CallState.Active
    val incoming = link.callState == CallState.Incoming
    val remote = e.remoteFrame
    val showVideo = link.callVideo && active && remote != null
    val kind = if (link.callVideo) "video" else "voice"
    val status = when (link.callState) {
        CallState.Outgoing -> "Calling..."
        CallState.Incoming -> "Incoming $kind call"
        else -> "${link.callSecs / 60}:${"%02d".format(link.callSecs % 60)}"
    }
    Box(Modifier.fillMaxSize().background(Pal.bg).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}) {
        Aurora(Modifier.fillMaxSize())
        if (showVideo && remote != null) {
            Image(bitmap = remote, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent, Color.Black.copy(alpha = 0.55f)))))
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(if (showVideo) 8.dp else 56.dp))
            if (!showVideo) {
                PulseAvatar(link.peerName, ringing = !active)
                Spacer(Modifier.height(22.dp))
            }
            Txt(link.peerName, if (showVideo) 20 else 30, FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Txt(status, 16, FontWeight.SemiBold, Pal.sub)
            Spacer(Modifier.weight(1f))
            if (incoming) {
                Row(horizontalArrangement = Arrangement.spacedBy(48.dp)) {
                    CallButton(ICON_CALL, RED, { link.hangUp() }, rot = 135f)
                    CallButton(if (link.callVideo) ICON_VIDEO else ICON_CALL, Pal.ok, { actions.answer() })
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    CallButton(ICON_MIC, if (e.muted) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.14f), { e.toggleMute() }, slash = e.muted)
                    if (link.callVideo) {
                        CallButton(ICON_VIDEO, if (!e.camOn) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.14f), { e.toggleCam() }, slash = !e.camOn)
                    }
                    CallButton(ICON_SPEAKER, if (e.speaker) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.14f), { e.toggleSpeaker() })
                    CallButton(ICON_CALL, RED, { link.hangUp() }, rot = 135f)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        val local = e.localFrame
        if (link.callVideo && active && local != null) {
            Box(
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(16.dp)
                    .size(104.dp, 144.dp).clip(RoundedCornerShape(22.dp))
                    .border(1.5.dp, RimBrush, RoundedCornerShape(22.dp))
            ) {
                Image(
                    bitmap = local, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = -1f }
                )
            }
        }
    }
}

@Composable
fun PulseAvatar(name: String, ringing: Boolean) {
    val t = rememberInfiniteTransition(label = "pulse")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "p")
    Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        if (ringing) {
            Canvas(Modifier.fillMaxSize()) {
                for (i in 0..1) {
                    val f = (p + i * 0.5f) % 1f
                    drawCircle(Pal.violet.copy(alpha = (1f - f) * 0.5f), size.minDimension / 2f * (0.5f + 0.5f * f), style = Stroke(2.dp.toPx()))
                }
            }
        }
        Avatar(name, 120.dp)
    }
}

@Composable
fun CallButton(icon: String, bg: Color, onClick: () -> Unit, rot: Float = 0f, slash: Boolean = false) {
    Pressable(onClick = onClick) {
        Box(
            Modifier.size(66.dp).clip(CircleShape).background(bg).border(1.dp, RimBrush, CircleShape),
            contentAlignment = Alignment.Center
        ) { SvgIcon(icon, Modifier.size(28.dp), rot = rot, slash = slash) }
    }
}

// ---------------------------------------------------------------------------
// Accept sheet
// ---------------------------------------------------------------------------

@Composable
fun AcceptSheet(p: Pending, onAccept: () -> Unit, onReject: () -> Unit) {
    val a = remember { Animatable(0.9f) }
    LaunchedEffect(Unit) { a.animateTo(1f, spring(dampingRatio = 0.65f, stiffness = 400f)) }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(28.dp)
                .graphicsLayer { scaleX = a.value; scaleY = a.value }
                .glass(RoundedCornerShape(34.dp), tint = Color.White.copy(alpha = 0.10f), blur = 32.dp)
                .padding(26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Txt("Connect to ${p.name}?", 22, FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Txt("Check this code matches on both phones", 14, FontWeight.Medium, Pal.sub)
            Spacer(Modifier.height(18.dp))
            Txt(p.code, 48, FontWeight.Black, Pal.text, spacing = 8f)
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Pressable(onClick = onReject) {
                    Box(Modifier.frost(CircleShape).padding(horizontal = 26.dp, vertical = 14.dp)) { Txt("Decline", 16, FontWeight.Bold) }
                }
                Pressable(onClick = onAccept) {
                    Box(
                        Modifier.clip(CircleShape).background(Brush.linearGradient(listOf(Pal.violet, Pal.blue)))
                            .padding(horizontal = 30.dp, vertical = 14.dp)
                    ) { Txt("Accept", 16, FontWeight.Black, Color.White) }
                }
            }
        }
    }
}
