# OfflineLink · Liquid Glass Edition

Professional offline messaging over **native Android Wi-Fi Direct**.

No internet. No router. No servers. Just two phones.

## What’s new (v2.0 Glass)
- Rich liquid-glass / glassmorphism UI inspired by modern iOS + premium Android design
- Multi-screen navigation: **Link · Chat · Info**
- Icons on every action (Host, Find, Connect, Send…)
- Soft entrance animations & overshoot message bubbles
- Subtle click sounds + haptic feedback
- Clean status indicators, empty states, and professional typography
- White glass cards, cyan accent links, rounded continuous corners

## How to use
1. Enable Wi-Fi on both phones (no internet or router required).
2. Install the app and grant Nearby Wi-Fi / Location permission.
3. On phone A → **Host**
4. On phone B → **Find** → tap **Connect** next to the other phone.
5. Once connected the app automatically switches to the **Chat** tab.
6. Message freely. Everything stays on the local Wi-Fi Direct link.

## Build
Use Android Studio or the included GitHub Actions workflow.  
The workflow produces `app-debug.apk`.

```bash
cd project/OfflineLink
./gradlew assembleDebug
```

## Notes
- Wi-Fi Direct behaviour varies by manufacturer.
- Android 12 and below also require Location services ON.
- Messages are currently **not end-to-end encrypted**. Treat as a prototype.
- Range is environment-dependent.

Made with liquid glass ✨
