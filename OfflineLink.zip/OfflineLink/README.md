# OfflineLink

Offline phone-to-phone chat for Android using Google Nearby Connections
(Bluetooth + Wi-Fi Direct / hotspot under the hood, no internet or router needed).

## Use
1. Install the APK on two Android phones (Android 8.0+, Google Play services required).
2. Phone A: tap **Host (broadcast)**. Phone B: tap **Join (search)**.
3. Accept on both phones after checking the code matches, then chat.

## Build the APK with GitHub
Push this repo to GitHub. The **Build APK** workflow runs on every push
(or run it manually in the Actions tab). Download `OfflineLink-debug-apk`
from the run's Artifacts, unzip it, and install `app-debug.apk`
(enable "Install unknown apps" on the phone).

## Notes
- Range is typically 10-30 m through walls, up to ~50+ m in open space.
- Turn on Bluetooth and Wi-Fi (no connection to a network needed), and Location on Android 11 and below.
