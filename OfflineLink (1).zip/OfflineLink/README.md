# OfflineLink 3.0

Offline phone-to-phone chat for Android (Google Nearby Connections), with a dark
glass UI. Phone A taps **Host**, phone B taps **Join**, confirm the code, chat.

- Discovery uses Bluetooth; the data link upgrades to Wi-Fi by itself when it can.
  The chat header shows which one you are on ("Wi-Fi · long range" or "Bluetooth · short range").
- If the link drops (you walk out of range) it reconnects automatically and sends queued messages.
- Real backdrop blur needs Android 12+; older phones get a frosted fallback.

## Build
Upload this zip (unchanged) and `.github/workflows/build-apk.yml` to GitHub.
The workflow unzips it and builds `app-debug.apk` (Actions -> Artifacts).

## Features
Text chat, voice messages, file and photo sharing, voice calls and video calls
(video needs the Wi-Fi link, shown in the chat header).
