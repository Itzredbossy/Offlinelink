package com.example.offlinelink

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.NetworkInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pDeviceList
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import android.util.Base64

/**
 * OfflineLink uses Android Wi-Fi Direct (Wi-Fi P2P) for the data connection.
 * It does not use a router, mobile data, internet, Nearby Connections, or Bluetooth.
 * One device creates a P2P group; the other discovers and joins it. Chat is carried
 * over a TCP socket on the resulting local Wi-Fi Direct network.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var root: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var detailText: TextView
    private lateinit var peerPanel: LinearLayout
    private lateinit var messagesPanel: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendButton: TextView
    private lateinit var hostButton: TextView
    private lateinit var joinButton: TextView

    private val io = Executors.newCachedThreadPool()
    private val socketClosed = AtomicBoolean(false)
    @Volatile private var socket: Socket? = null
    @Volatile private var writer: BufferedWriter? = null
    @Volatile private var server: ServerSocket? = null
    @Volatile private var serverStarted = false
    @Volatile private var socketConnecting = false
    @Volatile private var isHost = false
    @Volatile private var connected = false
    private var receiverRegistered = false
    private var peers: List<WifiP2pDevice> = emptyList()
    private var pendingPermissionAction: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) pendingPermissionAction?.invoke()
        else toast("Nearby Wi-Fi permission is required")
        pendingPermissionAction = null
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        setStatus("Wi-Fi Direct ready", "Ready to create or find a nearby link")
                    } else {
                        setStatus("Turn on Wi-Fi", "Wi-Fi must be enabled on both phones")
                    }
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> requestPeers()
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    val network = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                    if (network?.isConnected == true) requestConnectionInfo()
                    else if (connected) onSocketLost("Wi-Fi Direct connection lost")
                }
                WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> Unit
            }
        }
    }

    private val connectionInfoListener = WifiP2pManager.ConnectionInfoListener { info ->
        if (!info.groupFormed || info.groupOwnerAddress == null) return@ConnectionInfoListener
        val address = info.groupOwnerAddress.hostAddress ?: return@ConnectionInfoListener
        if (info.isGroupOwner) startServer() else connectToHost(address)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 9, 18)
        window.navigationBarColor = Color.rgb(8, 9, 18)
        window.decorView.systemUiVisibility = 0
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper) {
            runOnUiThread { setStatus("Wi-Fi Direct unavailable", "Restart Wi-Fi and try again") }
        }
        buildInterface()
        registerP2pReceiver()
        setStatus("Offline, by design", "Direct phone-to-phone Wi-Fi · No router or internet")
    }

    private fun buildInterface() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 9, 18), Color.rgb(17, 15, 39), Color.rgb(8, 9, 18)))
        }
        setContentView(root)

        val brand = row()
        val title = text("Offline", 34, Color.WHITE, true)
        brand.addView(title)
        brand.addView(text("Link", 34, Color.rgb(91, 163, 255), true))
        root.addView(brand, lp(-1, -2))
        root.addView(text("Private messages. Direct connection. No internet.", 14, 0xFFB9BED0.toInt(), false).apply {
            setPadding(0, dp(2), 0, dp(20))
        }, lp(-1, -2))

        val statusCard = card()
        statusText = text("Offline, by design", 18, Color.WHITE, true)
        detailText = text("Direct phone-to-phone Wi-Fi", 13, 0xFFB9BED0.toInt(), false)
        statusCard.addView(statusText, lp(-1, -2))
        statusCard.addView(detailText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        root.addView(statusCard, lp(-1, -2))

        val actions = row().apply { setPadding(0, dp(14), 0, dp(10)) }
        hostButton = actionButton("HOST", Color.rgb(112, 82, 255)) { withPermissions { host() } }
        joinButton = actionButton("FIND PHONE", Color.rgb(43, 132, 235)) { withPermissions { discover() } }
        actions.addView(hostButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        actions.addView(joinButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        root.addView(actions, lp(-1, -2))

        val peersCard = card()
        peersCard.addView(text("NEARBY PHONES", 11, 0xFF9DA5BE.toInt(), true), lp(-1, -2))
        peerPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        peersCard.addView(peerPanel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(peersCard, lp(-1, -2))

        val chatTitle = row().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(18), dp(3), dp(8))
        }
        chatTitle.addView(text("MESSAGES", 11, 0xFF9DA5BE.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        chatTitle.addView(text("ENCRYPTION NOT PROVIDED", 9, 0xFF7F879E.toInt(), true))
        root.addView(chatTitle, lp(-1, -2))

        scroll = ScrollView(this).apply { isFillViewport = true }
        messagesPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(12)) }
        scroll.addView(messagesPanel, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addSystemMessage("Choose Host on one phone and Find Phone on the other.")

        val composer = row().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(4))
        }
        input = EditText(this).apply {
            hint = "Write a message"
            setHintTextColor(0xFF8E95AA.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(16), dp(11), dp(16), dp(11))
            background = rounded(Color.rgb(31, 33, 54), 0x55FFFFFF, 24)
            isEnabled = false
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        sendButton = actionButton("SEND", Color.rgb(93, 111, 255)) { sendMessage() }.apply { isEnabled = false; alpha = 0.45f }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(8) })
        composer.addView(sendButton, lp(dp(82), dp(52)))
        root.addView(composer, lp(-1, -2))

        val footer = text("Wi-Fi Direct · Local-only socket · Android 12 and below may require Location ON", 10, 0xFF747D96.toInt(), false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(footer, lp(-1, -2))
    }

    @Suppress("DEPRECATION")
    private fun registerP2pReceiver() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, filter)
        receiverRegistered = true
    }

    private fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun withPermissions(action: () -> Unit) {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) action() else {
            pendingPermissionAction = action
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun host() {
        closeTransport()
        isHost = true
        setStatus("Starting Wi-Fi Direct group…", "This phone will host the local Wi-Fi link")
        peerPanel.removeAllViews()
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = createHostGroup()
            override fun onFailure(reason: Int) = createHostGroup()
        })
    }

    @Suppress("MissingPermission")
    private fun createHostGroup() {
        manager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                runOnUiThread { setStatus("Hosting", "Waiting for another phone to find and join") }
            }
            override fun onFailure(reason: Int) {
                runOnUiThread { setStatus("Couldn't start hosting", p2pError(reason)); addSystemMessage("Host failed: ${p2pError(reason)}") }
            }
        })
    }

    private fun discover() {
        closeTransport()
        isHost = false
        peers = emptyList()
        peerPanel.removeAllViews()
        setStatus("Searching nearby…", "Keep this screen open while Wi-Fi Direct scans")
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { runOnUiThread { addSystemMessage("Searching for nearby Wi-Fi Direct devices…") } }
            override fun onFailure(reason: Int) {
                runOnUiThread { setStatus("Search couldn't start", p2pError(reason)); addSystemMessage(p2pError(reason)) }
            }
        })
    }

    @Suppress("MissingPermission")
    private fun requestPeers() {
        manager.requestPeers(channel) { list: WifiP2pDeviceList ->
            peers = list.deviceList.filter { it.status != WifiP2pDevice.UNAVAILABLE }
            runOnUiThread { renderPeers() }
        }
    }

    private fun renderPeers() {
        peerPanel.removeAllViews()
        if (peers.isEmpty()) {
            peerPanel.addView(text("No phones found yet. Keep both devices nearby and tap Find Phone again.", 13, 0xFFB9BED0.toInt(), false))
            return
        }
        peers.forEach { device ->
            val item = row().apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(11), dp(10), dp(11))
                background = rounded(Color.rgb(31, 33, 54), 0x22FFFFFF, 16)
            }
            val label = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            label.addView(text(device.deviceName.ifBlank { "Nearby Android phone" }, 15, Color.WHITE, true))
            label.addView(text(deviceStatus(device.status), 11, 0xFF9DA5BE.toInt(), false))
            item.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val connect = actionButton("CONNECT", Color.rgb(54, 139, 239)) { connect(device) }
            item.addView(connect, lp(dp(98), dp(40)))
            peerPanel.addView(item, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
    }

    @Suppress("MissingPermission")
    private fun connect(device: WifiP2pDevice) {
        setStatus("Connecting…", "Negotiating a direct Wi-Fi link with ${device.deviceName}")
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { runOnUiThread { addSystemMessage("Connection request sent to ${device.deviceName}.") } }
            override fun onFailure(reason: Int) { runOnUiThread { setStatus("Connection failed", p2pError(reason)) } }
        })
    }

    @Suppress("MissingPermission")
    private fun requestConnectionInfo() {
        manager.requestConnectionInfo(channel, connectionInfoListener)
    }

    private fun startServer() {
        if (serverStarted) return
        serverStarted = true
        io.execute {
            try {
                val ss = ServerSocket(PORT)
                server = ss
                val accepted = ss.accept()
                attachSocket(accepted)
            } catch (e: Exception) {
                if (!socketClosed.get()) runOnUiThread { setStatus("Waiting for peer", e.message ?: "Socket server stopped") }
            }
        }
        runOnUiThread { setStatus("Wi-Fi Direct active", "Group created · waiting for the other phone's chat socket") }
    }

    private fun connectToHost(address: String) {
        if (connected || socket != null || socketConnecting) return
        socketConnecting = true
        io.execute {
            try {
                val s = Socket()
                s.connect(java.net.InetSocketAddress(address, PORT), 12000)
                socketConnecting = false
                attachSocket(s)
            } catch (e: Exception) {
                socketConnecting = false
                runOnUiThread { setStatus("Socket connection failed", e.message ?: "Try reconnecting") }
            }
        }
    }

    private fun attachSocket(s: Socket) {
        socket = s
        socketClosed.set(false)
        writer = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
        connected = true
        socketConnecting = false
        runOnUiThread {
            setStatus("Connected · Wi-Fi Direct", "Direct local Wi-Fi link · no router or internet")
            input.isEnabled = true
            sendButton.isEnabled = true
            sendButton.alpha = 1f
            addSystemMessage("Secure transport is connected. Messages travel over Wi-Fi Direct.")
        }
        io.execute {
            try {
                val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                while (!s.isClosed) {
                    val line = reader.readLine() ?: break
                    val decoded = try { String(Base64.decode(line, Base64.NO_WRAP), Charsets.UTF_8) } catch (_: Exception) { continue }
                    runOnUiThread { addMessage(decoded, false) }
                }
            } catch (_: Exception) {
            } finally {
                if (!socketClosed.get()) onSocketLost("Peer disconnected")
            }
        }
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        val out = writer
        if (!connected || out == null) {
            toast("Not connected yet")
            return
        }
        val encoded = Base64.encodeToString(message.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        io.execute {
            try {
                synchronized(out) { out.write(encoded); out.newLine(); out.flush() }
                runOnUiThread { addMessage(message, true); input.setText("") }
            } catch (e: Exception) {
                runOnUiThread { onSocketLost("Message could not be sent") }
            }
        }
    }

    private fun onSocketLost(reason: String) {
        connected = false
        closeSocketOnly()
        runOnUiThread {
            input.isEnabled = false
            sendButton.isEnabled = false
            sendButton.alpha = 0.45f
            setStatus("Disconnected", reason)
            addSystemMessage(reason)
        }
    }

    private fun closeSocketOnly() {
        socketClosed.set(true)
        try { writer?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        writer = null
        socket = null
    }

    private fun closeTransport() {
        connected = false
        serverStarted = false
        socketConnecting = false
        closeSocketOnly()
        try { server?.close() } catch (_: Exception) {}
        server = null
        input.isEnabled = false
        sendButton.isEnabled = false
        sendButton.alpha = 0.45f
    }

    private fun addMessage(message: String, mine: Boolean) {
        val line = TextView(this).apply {
            text = message
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(
                if (mine) Color.rgb(91, 83, 220) else Color.rgb(38, 41, 64),
                0x55FFFFFF, 18
            )
        }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.END else Gravity.START
            line.maxWidth = dp(290)
            addView(line, LinearLayout.LayoutParams(-2, -2))
            alpha = 0f
            translationY = dp(10).toFloat()
        }
        messagesPanel.addView(wrapper, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
        wrapper.animate().alpha(1f).translationY(0f).setDuration(220).start()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addSystemMessage(message: String) {
        val v = text(message, 12, 0xFF969FB8.toInt(), false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        messagesPanel.addView(v, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setStatus(title: String, detail: String) {
        statusText.text = title
        detailText.text = detail
    }

    private fun p2pError(reason: Int): String = when (reason) {
        WifiP2pManager.P2P_UNSUPPORTED -> "This phone does not support Wi-Fi Direct"
        WifiP2pManager.BUSY -> "Wi-Fi Direct is busy. Wait a moment and retry"
        WifiP2pManager.ERROR -> "Wi-Fi Direct system error"
        else -> "Wi-Fi Direct error ($reason)"
    }

    private fun deviceStatus(status: Int): String = when (status) {
        WifiP2pDevice.AVAILABLE -> "Available"
        WifiP2pDevice.INVITED -> "Invited"
        WifiP2pDevice.CONNECTED -> "Connected"
        WifiP2pDevice.FAILED -> "Connection failed"
        else -> "Nearby device"
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 12f
        letterSpacing = 0.06f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = rounded(color, 0x66FFFFFF, 18)
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(0xDD191B30.toInt(), 0x44FFFFFF, 22)
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        closeTransport()
        try { manager.stopPeerDiscovery(channel, null) } catch (_: Exception) {}
        try { manager.removeGroup(channel, null) } catch (_: Exception) {}
        if (receiverRegistered) try { unregisterReceiver(receiver) } catch (_: Exception) {}
        io.shutdownNow()
        super.onDestroy()
    }

    companion object { private const val PORT = 8988 }
}
