package com.example.offlinelink

import android.bluetooth.BluetoothManager
import android.content.Context
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.location.LocationManagerCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File
import java.io.OutputStream
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.BandwidthInfo
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy

enum class Phase { Idle, Hosting, Searching, Chat }
enum class Role { Host, Join }
enum class LinkType { Unknown, Bluetooth, Wifi }

enum class Kind { Text, File, Voice, Call }
enum class CallState { Idle, Outgoing, Incoming, Active }

class Msg(
    val kind: Kind,
    val text: String,
    val mine: Boolean,
    sent: Boolean,
    val name: String = "",
    val size: Long = 0L,
    val durMs: Long = 0L,
    path: String? = null,
    progress: Float = 1f
) {
    var sent by mutableStateOf(sent)
    var inFlight = false
    var path by mutableStateOf(path)
    var progress by mutableFloatStateOf(progress)
}

class Pending(val id: String, val name: String, val code: String)

data class Ready(
    val wifi: Boolean,
    val bluetooth: Boolean,
    val location: Boolean,
    val needsLocation: Boolean
)

fun readiness(ctx: Context): Ready {
    val app = ctx.applicationContext
    val wm = app.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    val bm = app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    return Ready(
        wifi = wm?.isWifiEnabled == true,
        bluetooth = bm?.adapter?.isEnabled == true,
        location = lm != null && LocationManagerCompat.isLocationEnabled(lm),
        needsLocation = Build.VERSION.SDK_INT <= 32
    )
}

/**
 * Nearby Connections wrapper. Discovery and the handshake happen over Bluetooth;
 * Nearby then upgrades the data link to Wi-Fi on its own when it can. We surface
 * which one is active so range problems are visible, reconnect automatically when
 * the link drops, and queue messages until the other phone is reachable again.
 */
class LinkController(private val context: Context, owner: LifecycleOwner) {

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context)
    private val serviceId = "com.example.offlinelink.SERVICE"
    private val strategy = Strategy.P2P_POINT_TO_POINT
    private val handler = Handler(Looper.getMainLooper())
    private val tick = Handler(Looper.getMainLooper())
    private val names = mutableMapOf<String, String>()
    private val byId = mutableMapOf<Long, Msg>()
    private val filePayloads = mutableMapOf<Long, Payload>()
    private val done = mutableSetOf<Long>()
    private val kinds = mutableMapOf<Long, Char>()
    private val streams = mutableMapOf<Long, Payload>()
    private val myStreams = mutableListOf<Long>()
    val engine = CallEngine(context, owner)

    val myName: String = Build.MODEL ?: "Phone"
    val messages = mutableStateListOf<Msg>()

    var phase by mutableStateOf(Phase.Idle)
        private set
    var online by mutableStateOf(false)
        private set
    var peerName by mutableStateOf("")
        private set
    var linkType by mutableStateOf(LinkType.Unknown)
        private set
    var pending by mutableStateOf<Pending?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var callState by mutableStateOf(CallState.Idle)
        private set
    var callVideo by mutableStateOf(false)
        private set
    var callSecs by mutableIntStateOf(0)
        private set

    private var role: Role? = null
    private var peerId: String? = null
    private var requesting = false

    // ---- public API -------------------------------------------------------

    fun host() = begin(Role.Host)

    fun join() = begin(Role.Join)

    fun leave() {
        endCall(false)
        handler.removeCallbacksAndMessages(null)
        stopNearby()
        role = null
        phase = Phase.Idle
        peerName = ""
        messages.clear()
    }

    fun shutdown() {
        endCall(false)
        handler.removeCallbacksAndMessages(null)
        stopNearby()
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val m = Msg(Kind.Text, t, mine = true, sent = false)
        messages.add(m)
        if (online) transmit(m)
    }

    fun accept() {
        val p = pending ?: return
        pending = null
        client.acceptConnection(p.id, payloadCb)
    }

    fun reject() {
        val p = pending ?: return
        pending = null
        requesting = false
        client.rejectConnection(p.id)
    }

    fun report(msg: String) {
        error = msg
    }

    fun clearError() {
        error = null
    }

    fun sendFile(uri: Uri) {
        if (!online) { error = "Not connected. Move closer and try again."; return }
        Thread {
            try {
                val name = displayName(uri)
                val dir = File(context.cacheDir, "out").apply { mkdirs() }
                val f = File(dir, "${System.currentTimeMillis()}_$name")
                context.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                handler.post { sendLocal(f, 'F', name, 0L) }
            } catch (e: Exception) {
                handler.post { error = "Couldn't read that file" }
            }
        }.start()
    }

    fun sendVoice(f: File, durMs: Long) {
        if (!online) { error = "Not connected. Move closer and try again."; return }
        sendLocal(f, 'V', "Voice message", durMs)
    }

    fun startCall(video: Boolean) {
        if (!online) { error = "Not connected. Move closer and try again."; return }
        if (callState != CallState.Idle) return
        callVideo = video
        callState = CallState.Outgoing
        line("C|INVITE|" + if (video) "1" else "0")
    }

    fun acceptCall() {
        if (callState != CallState.Incoming) return
        line("C|ACCEPT")
        beginMedia()
    }

    fun hangUp() {
        line("C|END")
        endCall(true)
    }

    // ---- internals --------------------------------------------------------

    private fun line(s: String) {
        val id = peerId ?: return
        client.sendPayload(id, Payload.fromBytes(s.toByteArray(Charsets.UTF_8)))
    }

    private fun displayName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i).replace('|', '_')
            }
        }
        return "file"
    }

    private fun sendLocal(f: File, kind: Char, name: String, durMs: Long) {
        val id = peerId ?: return
        val payload = try { Payload.fromFile(f) } catch (e: Exception) { error = "Couldn't send that file"; return }
        val safe = name.replace('|', '_')
        val m = Msg(if (kind == 'V') Kind.Voice else Kind.File, safe, true, false, safe, f.length(), durMs, f.absolutePath, 0f)
        messages.add(m)
        byId[payload.id] = m
        line("M|${payload.id}|$kind|$safe|${f.length()}|$durMs")
        client.sendPayload(id, payload)
    }

    private fun tryFinalize(id: Long) {
        val m = byId[id] ?: return
        val p = filePayloads[id] ?: return
        if (m.mine || !done.contains(id)) return
        filePayloads.remove(id)
        Thread {
            try {
                val dir = File(context.cacheDir, "in").apply { mkdirs() }
                val f = File(dir, "${id}_${m.name}")
                val pfd = p.asFile()?.asParcelFileDescriptor() ?: return@Thread
                ParcelFileDescriptor.AutoCloseInputStream(pfd).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                handler.post { m.path = f.absolutePath; m.progress = 1f }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun maybeStartStream(id: Long) {
        val k = kinds[id] ?: return
        val p = streams[id] ?: return
        kinds.remove(id)
        streams.remove(id)
        p.asStream()?.asInputStream()?.let { engine.onRemoteStream(k, it) }
    }

    private fun openOut(kind: Char): OutputStream {
        val pipe = ParcelFileDescriptor.createPipe()
        val p = Payload.fromStream(pipe[0])
        line("S|${p.id}|$kind")
        peerId?.let { client.sendPayload(it, p) }
        myStreams.add(p.id)
        return ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
    }

    private fun beginMedia() {
        callState = CallState.Active
        callSecs = 0
        tick.removeCallbacksAndMessages(null)
        tick.postDelayed(object : Runnable {
            override fun run() {
                if (callState == CallState.Active) { callSecs++; tick.postDelayed(this, 1000) }
            }
        }, 1000)
        engine.start(callVideo) { openOut(it) }
    }

    private fun endCall(log: Boolean) {
        if (callState == CallState.Idle) return
        val wasActive = callState == CallState.Active
        tick.removeCallbacksAndMessages(null)
        engine.stop()
        myStreams.forEach { client.cancelPayload(it) }
        myStreams.clear()
        kinds.clear()
        streams.clear()
        if (log && wasActive) {
            val label = if (callVideo) "Video call" else "Voice call"
            messages.add(Msg(Kind.Call, "$label · ${callSecs / 60}:${"%02d".format(callSecs % 60)}", false, true))
        }
        callState = CallState.Idle
    }

    private fun onLine(s: String) {
        val p = s.split('|', limit = 6)
        when (p[0]) {
            "T" -> messages.add(Msg(Kind.Text, s.substring(2), false, true))
            "M" -> if (p.size >= 6) {
                val id = p[1].toLongOrNull() ?: return
                val m = Msg(
                    if (p[2] == "V") Kind.Voice else Kind.File, p[3], false, true,
                    p[3], p[4].toLongOrNull() ?: 0L, p[5].toLongOrNull() ?: 0L, null, 0f
                )
                messages.add(m)
                byId[id] = m
                tryFinalize(id)
            }
            "S" -> if (p.size >= 3 && p[2].isNotEmpty()) {
                val id = p[1].toLongOrNull() ?: return
                kinds[id] = p[2][0]
                maybeStartStream(id)
            }
            "C" -> when (p.getOrNull(1)) {
                "INVITE" -> if (callState != CallState.Idle) line("C|END") else {
                    callVideo = p.getOrNull(2) == "1"
                    callState = CallState.Incoming
                }
                "ACCEPT" -> if (callState == CallState.Outgoing) beginMedia()
                "END" -> endCall(true)
            }
        }
    }

    private fun begin(r: Role) {
        handler.removeCallbacksAndMessages(null)
        stopNearby()
        messages.clear()
        error = null
        role = r
        phase = if (r == Role.Host) Phase.Hosting else Phase.Searching
        startRole()
    }

    private fun stopNearby() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        peerId = null
        online = false
        requesting = false
        pending = null
        linkType = LinkType.Unknown
    }

    private fun startRole() {
        when (role) {
            Role.Host -> client.startAdvertising(
                myName, serviceId, connectionCb,
                AdvertisingOptions.Builder().setStrategy(strategy).build()
            ).addOnFailureListener { fail("Couldn't start hosting: ${it.message}") }

            Role.Join -> client.startDiscovery(
                serviceId, discoveryCb,
                DiscoveryOptions.Builder().setStrategy(strategy).build()
            ).addOnFailureListener { fail("Couldn't start searching: ${it.message}") }

            null -> {}
        }
    }

    private fun fail(msg: String) {
        if (phase == Phase.Chat) {
            scheduleRestart()
        } else {
            error = msg
            role = null
            phase = Phase.Idle
        }
    }

    private fun scheduleRestart() {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (role != null && !online) {
                client.stopAdvertising()
                client.stopDiscovery()
                requesting = false
                startRole()
            }
        }, 1500)
    }

    private fun transmit(m: Msg) {
        val id = peerId ?: return
        if (m.inFlight || m.sent) return
        m.inFlight = true
        client.sendPayload(id, Payload.fromBytes(("T|" + m.text).toByteArray(Charsets.UTF_8)))
            .addOnSuccessListener { m.sent = true }
            .addOnFailureListener { m.inFlight = false }
    }

    private fun flushQueue() {
        messages.filter { it.kind == Kind.Text && it.mine && !it.sent }.forEach { transmit(it) }
    }

    // ---- Nearby callbacks -------------------------------------------------

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> payload.asBytes()?.let { onLine(String(it, Charsets.UTF_8)) }
                Payload.Type.FILE -> { filePayloads[payload.id] = payload; tryFinalize(payload.id) }
                Payload.Type.STREAM -> { streams[payload.id] = payload; maybeStartStream(payload.id) }
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            val m = byId[update.payloadId]
            if (m != null && update.totalBytes > 0) {
                m.progress = (update.bytesTransferred.toFloat() / update.totalBytes).coerceIn(0f, 1f)
            }
            if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                done.add(update.payloadId)
                if (m != null && m.mine) { m.sent = true; m.progress = 1f }
                tryFinalize(update.payloadId)
            }
        }
    }

    private val connectionCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            names[endpointId] = info.endpointName
            // Reconnecting to the same peer during an open chat: no need to ask again.
            val reconnect = phase == Phase.Chat && info.endpointName == peerName
            if (reconnect) {
                client.acceptConnection(endpointId, payloadCb)
            } else {
                pending = Pending(endpointId, info.endpointName, info.authenticationDigits)
            }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            requesting = false
            if (result.status.isSuccess) {
                handler.removeCallbacksAndMessages(null)
                client.stopAdvertising()
                client.stopDiscovery()
                peerId = endpointId
                peerName = names[endpointId] ?: peerName
                online = true
                phase = Phase.Chat
                flushQueue()
            } else {
                pending = null
                if (phase != Phase.Chat) error = "Connection was declined or failed"
                scheduleRestart()
            }
        }

        override fun onDisconnected(endpointId: String) {
            if (endpointId != peerId) return
            peerId = null
            online = false
            requesting = false
            linkType = LinkType.Unknown
            endCall(true)
            messages.forEach { if (!it.sent) it.inFlight = false }
            if (phase == Phase.Chat) scheduleRestart()
        }

        override fun onBandwidthChanged(endpointId: String, bandwidthInfo: BandwidthInfo) {
            linkType = when (bandwidthInfo.quality) {
                BandwidthInfo.Quality.HIGH -> LinkType.Wifi
                BandwidthInfo.Quality.MEDIUM, BandwidthInfo.Quality.LOW -> LinkType.Bluetooth
                else -> LinkType.Unknown
            }
        }
    }

    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            if (requesting || online) return
            if (phase == Phase.Chat && info.endpointName != peerName) return
            requesting = true
            names[endpointId] = info.endpointName
            client.requestConnection(myName, endpointId, connectionCb)
                .addOnFailureListener {
                    requesting = false
                    if (phase != Phase.Chat) error = "Couldn't reach the host: ${it.message}"
                    scheduleRestart()
                }
        }

        override fun onEndpointLost(endpointId: String) {}
    }
}
