package com.example.offlinelink

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var link: LinkController
    private lateinit var recorder: VoiceRecorder
    private var pendingAction: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) pendingAction?.invoke()
            else link.report("Permission denied. OfflineLink needs it for this feature.")
            pendingAction = null
        }

    private val picker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) link.sendFile(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        link = LinkController(applicationContext, this)
        recorder = VoiceRecorder(applicationContext)
        val actions = Actions(
            host = { withPerms(nearbyPerms()) { link.host() } },
            join = { withPerms(nearbyPerms()) { link.join() } },
            pick = { picker.launch("*/*") },
            withMic = { a -> withPerms(arrayOf(Manifest.permission.RECORD_AUDIO), a) },
            startCall = { video -> withPerms(callPerms(video)) { link.startCall(video) } },
            answer = { withPerms(callPerms(link.callVideo)) { link.acceptCall() } }
        )
        setContent { OfflineLinkApp(link, recorder, actions) }
    }

    override fun onDestroy() {
        recorder.cancel()
        link.shutdown()
        super.onDestroy()
    }

    private fun callPerms(video: Boolean): Array<String> =
        if (video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        else arrayOf(Manifest.permission.RECORD_AUDIO)

    private fun nearbyPerms(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.NEARBY_WIFI_DEVICES
        )
        Build.VERSION.SDK_INT >= 31 -> arrayOf(
            Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION
        )
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun withPerms(perms: Array<String>, action: () -> Unit) {
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            permLauncher.launch(missing.toTypedArray())
        }
    }
}
