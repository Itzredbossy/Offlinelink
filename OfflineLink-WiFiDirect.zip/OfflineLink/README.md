# OfflineLink

OfflineLink is a two-phone Android chat prototype using **native Android Wi-Fi Direct (Wi-Fi P2P)** for the data path. It does not use Google Nearby Connections or Bluetooth for chat transport.

## How to use
1. Enable Wi-Fi on both phones. Neither phone needs to join a router or have internet access.
2. Install the app on both phones and grant the Nearby Wi-Fi permission (or Location permission on Android 12 and below).
3. On phone A, tap **HOST**.
4. On phone B, tap **FIND PHONE**, then tap **CONNECT** beside phone A when it appears. On Android 12 and below, turn Location services on as well as granting Location permission.
5. Wait for the Wi-Fi Direct group and local socket to connect, then chat.

## Important limitations
- Wi-Fi Direct support and behavior vary by Android device/vendor. Some devices restrict P2P while a Wi-Fi hotspot, VPN, or certain Wi-Fi modes are active.
- 50 metres is a target, not a guarantee. Walls, floors, interference, antenna design, and regional radio power limits affect range. Test in the actual environment.
- This prototype sends chat text over a local TCP socket. It does **not** yet implement end-to-end encryption, durable offline message queues, background operation, or automatic recovery after the Wi-Fi Direct group is lost. Do not use it for sensitive messages.
- Both phones need Wi-Fi enabled. No internet connection is required. Android may still show Wi-Fi as connected to a peer-created local group; that is not an internet connection.

## Build
The GitHub Actions workflow builds `app-debug.apk` on push or manual dispatch. The artifact is named `OfflineLink-debug-apk`.
