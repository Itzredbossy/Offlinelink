package com.example.offlinelink

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.Executors

private const val RATE = 16000

/** Live audio (PCM over a Nearby stream) and video (JPEG frames over a second stream). */
class CallEngine(private val ctx: Context, private val owner: LifecycleOwner) {

    var remoteFrame by mutableStateOf<ImageBitmap?>(null)
    var localFrame by mutableStateOf<ImageBitmap?>(null)
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)
    var camOn by mutableStateOf(true)

    @Volatile private var running = false
    @Volatile private var videoOut: DataOutputStream? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var provider: ProcessCameraProvider? = null
    private val inputs = mutableListOf<InputStream>()
    private val exec = Executors.newSingleThreadExecutor()
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var lastFrame = 0L

    fun start(video: Boolean, open: (Char) -> OutputStream) {
        stop()
        running = true
        muted = false
        camOn = true
        speaker = video
        audio.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION")
        audio.isSpeakerphoneOn = speaker
        val out = open('A')
        Thread { pumpMic(out) }.start()
        if (video) {
            videoOut = DataOutputStream(BufferedOutputStream(open('V')))
            startCamera()
        }
    }

    fun onRemoteStream(kind: Char, input: InputStream) {
        synchronized(inputs) { inputs.add(input) }
        if (kind == 'A') Thread { playAudio(input) }.start() else Thread { readVideo(input) }.start()
    }

    fun toggleMute() { muted = !muted }

    fun toggleSpeaker() {
        speaker = !speaker
        @Suppress("DEPRECATION")
        audio.isSpeakerphoneOn = speaker
    }

    fun toggleCam() {
        camOn = !camOn
        if (!camOn) {
            localFrame = null
            sendFrame(null)
        }
    }

    fun stop() {
        running = false
        try { provider?.unbindAll() } catch (_: Exception) {}
        provider = null
        synchronized(inputs) {
            inputs.forEach { try { it.close() } catch (_: Exception) {} }
            inputs.clear()
        }
        try { videoOut?.close() } catch (_: Exception) {}
        videoOut = null
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        track = null
        audio.mode = AudioManager.MODE_NORMAL
        @Suppress("DEPRECATION")
        audio.isSpeakerphoneOn = false
        remoteFrame = null
        localFrame = null
    }

    @SuppressLint("MissingPermission")
    private fun pumpMic(out: OutputStream) {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2
        )
        record = rec
        val buf = ByteArray(min)
        try {
            rec.startRecording()
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0 && !muted) {
                    out.write(buf, 0, n)
                    out.flush()
                }
            }
        } catch (_: Exception) {
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            try { out.close() } catch (_: Exception) {}
        }
    }

    private fun playAudio(input: InputStream) {
        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
            )
            .setBufferSizeInBytes(min * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        val buf = ByteArray(min)
        try {
            t.play()
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                if (n > 0) t.write(buf, 0, n)
            }
        } catch (_: Exception) {
        }
    }

    private fun readVideo(input: InputStream) {
        try {
            val din = DataInputStream(BufferedInputStream(input))
            while (true) {
                val len = din.readInt()
                if (len == 0) { remoteFrame = null; continue }
                if (len < 0 || len > 2_000_000) break
                val b = ByteArray(len)
                din.readFully(b)
                BitmapFactory.decodeByteArray(b, 0, len)?.let { remoteFrame = it.asImageBitmap() }
            }
        } catch (_: Exception) {
        }
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(ctx)
        f.addListener({
            try {
                val p = f.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetResolution(Size(480, 360))
                    .build()
                analysis.setAnalyzer(exec) { handleFrame(it) }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun handleFrame(img: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (!camOn || now - lastFrame < 80) return
            lastFrame = now
            var bmp = img.toBitmap()
            val rot = img.imageInfo.rotationDegrees
            if (rot != 0) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            }
            localFrame = bmp.asImageBitmap()
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 55, bos)
            sendFrame(bos.toByteArray())
        } catch (_: Exception) {
        } finally {
            img.close()
        }
    }

    private fun sendFrame(bytes: ByteArray?) {
        val vo = videoOut ?: return
        try {
            synchronized(vo) {
                if (bytes == null) vo.writeInt(0) else { vo.writeInt(bytes.size); vo.write(bytes) }
                vo.flush()
            }
        } catch (_: Exception) {
        }
    }
}

/** Records AAC voice messages to the cache folder. */
class VoiceRecorder(private val ctx: Context) {
    var recording by mutableStateOf(false)
        private set
    var elapsedMs by mutableLongStateOf(0L)
        private set
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var t0 = 0L

    fun start() {
        if (recording) return
        try {
            val dir = File(ctx.cacheDir, "out").apply { mkdirs() }
            val f = File(dir, "voice_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(64000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            t0 = SystemClock.elapsedRealtime()
            elapsedMs = 0L
            recording = true
        } catch (_: Exception) {
            cancel()
        }
    }

    fun tick() { if (recording) elapsedMs = SystemClock.elapsedRealtime() - t0 }

    /** Returns the file and its length in ms, or null if it failed or was too short. */
    fun stop(): Pair<File, Long>? {
        val r = rec ?: return null
        val f = file
        val d = SystemClock.elapsedRealtime() - t0
        rec = null
        recording = false
        return try {
            r.stop()
            r.release()
            if (f != null && d >= 700) f to d else { f?.delete(); null }
        } catch (_: Exception) {
            try { r.release() } catch (_: Exception) {}
            f?.delete()
            null
        }
    }

    fun cancel() {
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        rec = null
        recording = false
        file?.delete()
        file = null
    }
}
