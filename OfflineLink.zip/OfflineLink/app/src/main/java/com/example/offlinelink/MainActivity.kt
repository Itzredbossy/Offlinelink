package com.example.offlinelink

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy

/**
 * Offline phone-to-phone chat using Google Nearby Connections.
 * One phone taps "Host" (advertises), the other taps "Join" (discovers).
 * Nearby picks Bluetooth / Wi-Fi Direct / hotspot automatically; no internet needed.
 */
class MainActivity : AppCompatActivity() {

    private val serviceId = "com.example.offlinelink.SERVICE"
    private val strategy = Strategy.P2P_POINT_TO_POINT

    private lateinit var client: ConnectionsClient
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button

    private var peerId: String? = null
    private var pending: (() -> Unit)? = null
    private val myName: String = Build.MODEL ?: "Phone"

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) {
                pending?.invoke()
            } else {
                log("Permissions denied. The app can't work without them.")
            }
            pending = null
        }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            payload.asBytes()?.let { log("Them: " + String(it, Charsets.UTF_8)) }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Connect to ${info.endpointName}?")
                .setMessage("Both phones should show this code:\n\n${info.authenticationDigits}")
                .setCancelable(false)
                .setPositiveButton("Accept") { _, _ ->
                    client.acceptConnection(endpointId, payloadCallback)
                }
                .setNegativeButton("Reject") { _, _ ->
                    client.rejectConnection(endpointId)
                }
                .show()
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                peerId = endpointId
                client.stopAdvertising()
                client.stopDiscovery()
                setConnected(true)
                log("Connected.")
            } else {
                log("Connection failed: ${result.status.statusMessage ?: result.status.statusCode}")
            }
        }

        override fun onDisconnected(endpointId: String) {
            peerId = null
            setConnected(false)
            log("Disconnected.")
        }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            log("Found ${info.endpointName}, requesting connection...")
            client.requestConnection(myName, endpointId, connectionCallback)
                .addOnFailureListener { log("Request failed: ${it.message}") }
        }

        override fun onEndpointLost(endpointId: String) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        client = Nearby.getConnectionsClient(this)
        statusView = findViewById(R.id.status)
        logView = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        input = findViewById(R.id.input)
        sendBtn = findViewById(R.id.sendBtn)

        findViewById<Button>(R.id.hostBtn).setOnClickListener { withPermissions { startHosting() } }
        findViewById<Button>(R.id.joinBtn).setOnClickListener { withPermissions { startJoining() } }
        sendBtn.setOnClickListener { sendMessage() }
    }

    override fun onDestroy() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        super.onDestroy()
    }

    private fun startHosting() {
        resetNearby()
        client.startAdvertising(
            myName, serviceId, connectionCallback,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        ).addOnSuccessListener {
            statusView.text = "Hosting, waiting for a phone..."
            log("Broadcasting as $myName.")
        }.addOnFailureListener { log("Host failed: ${it.message}") }
    }

    private fun startJoining() {
        resetNearby()
        client.startDiscovery(
            serviceId, discoveryCallback,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        ).addOnSuccessListener {
            statusView.text = "Searching for a host..."
            log("Searching...")
        }.addOnFailureListener { log("Search failed: ${it.message}") }
    }

    private fun resetNearby() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        peerId = null
        setConnected(false)
    }

    private fun sendMessage() {
        val id = peerId ?: return
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        client.sendPayload(id, Payload.fromBytes(text.toByteArray(Charsets.UTF_8)))
            .addOnSuccessListener {
                log("Me: $text")
                input.setText("")
            }
            .addOnFailureListener { log("Send failed: ${it.message}") }
    }

    private fun setConnected(connected: Boolean) {
        statusView.text = if (connected) "Connected" else "Not connected"
        input.isEnabled = connected
        sendBtn.isEnabled = connected
    }

    private fun log(line: String) {
        logView.append(line + "\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.NEARBY_WIFI_DEVICES
        )
        Build.VERSION.SDK_INT >= 31 -> arrayOf(
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun withPermissions(action: () -> Unit) {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            action()
        } else {
            pending = action
            permLauncher.launch(missing.toTypedArray())
        }
    }
}
